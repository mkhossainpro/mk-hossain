document.writeln("<script src=\"//cdn.jsdelivr.net/npm/hls.js@latest\"></script>");
